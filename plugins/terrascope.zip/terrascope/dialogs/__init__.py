"""
Terrascope Plugin Dialogs

This module contains the dialog and dock widget classes for the Terrascope plugin.
"""
