"""
HyperCoast QGIS Plugin Core Module

Contains the dependency management components: standalone Python downloading,
uv package installer management, and virtual environment management.
"""
