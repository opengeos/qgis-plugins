"""
Dialog and dock widget classes for the STAC Explorer plugin.
"""
