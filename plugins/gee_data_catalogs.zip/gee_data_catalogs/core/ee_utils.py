"""
Earth Engine Utilities for GEE Data Catalogs

This module provides utility functions for working with Earth Engine in QGIS.
"""

import json
import os
import time
from typing import Any, Dict, List, Optional
from urllib.parse import quote

try:
    import ee
except ImportError:
    ee = None

from qgis.core import (
    QgsProject,
    QgsRasterLayer,
    QgsMessageLog,
    Qgis,
)

# Track if EE has been initialized
_ee_initialized = False
_last_init_error: Optional[str] = None

# Global registry to track EE layers for Inspector
_ee_layer_registry = {}

# Identifier that the earthengine-api sends to Earth Engine on every API call
# (getMapId, getInfo, etc.). The official QGIS GEE plugin does the same so EE
# can attribute traffic and apply the right per-client quotas. This does not
# affect tile fetches (those go through QGIS's network manager), only the
# Python-side EE API calls.
_EE_USER_AGENT = "qgis-gee-data-catalogs-plugin/0.11.0"
_ee_user_agent_set = False


def _set_ee_user_agent_once() -> None:
    """Set a stable User-Agent for ee.data API calls (idempotent)."""
    global _ee_user_agent_set
    if _ee_user_agent_set or ee is None:
        return
    try:
        if ee.data.getUserAgent() != _EE_USER_AGENT:
            ee.data.setUserAgent(_EE_USER_AGENT)
    except Exception:  # nosec B110 - best-effort, never fail init on this
        return
    _ee_user_agent_set = True


# Cache of (asset_repr, hashable_vis_params) -> tile_url. Populated after a
# successful getMapId() call so repeated adds of the same dataset (very common
# when iterating in the AI Assistant) skip the network round-trip. Cleared
# whenever Earth Engine is re-initialized to avoid stale URLs after re-auth.
_tile_url_cache: Dict[tuple, str] = {}
_TILE_CACHE_CAP = 64


def _hashable_vis_params(vis_params: Dict) -> tuple:
    """Return a hashable representation of vis_params for use as a cache key.

    Values that are lists (e.g. ``palette``, ``bands``) are converted to
    tuples so the resulting key is hashable. Items are sorted by key so two
    dicts with the same contents produce the same key regardless of insertion
    order.

    Args:
        vis_params: Visualization parameters dict.

    Returns:
        A tuple of (key, value) pairs suitable for use in a dict key.
    """
    items = []
    for key, value in sorted(vis_params.items()):
        if isinstance(value, list):
            value = tuple(value)
        items.append((key, value))
    return tuple(items)


def _tile_cache_key(ee_object: Any, vis_params: Dict) -> Optional[tuple]:
    """Build a cache key for an EE object + vis_params combination.

    Uses ``ee_object.serialize()`` when available (every ``ComputedObject``
    has it) so the key reflects the full computation graph, not just the
    Python object identity. Returns ``None`` if a stable key cannot be built,
    in which case the caller should bypass the cache.

    Args:
        ee_object: An Earth Engine object.
        vis_params: Visualization parameters dict.

    Returns:
        A hashable tuple key, or None if the object cannot be serialized.
    """
    try:
        asset_repr = ee_object.serialize()
    except Exception:  # nosec B110 - fall back to bypassing the cache
        return None
    return (asset_repr, _hashable_vis_params(vis_params))


def _clear_tile_url_cache() -> None:
    """Drop all cached tile URLs. Called after a successful EE re-init."""
    _tile_url_cache.clear()


def _xyz_uri_from_tile_url(tile_url: str) -> str:
    """Return a QGIS XYZ datasource URI with the nested tile URL encoded."""
    encoded_url = quote(tile_url, safe=":/{}")
    return f"type=xyz&url={encoded_url}&zmax=24&zmin=0"


def _normalize_ee_asset_type(asset_type: str) -> str:
    """Normalize Earth Engine asset type names from catalog/API metadata."""
    normalized = str(asset_type or "").lower().replace("_", "").replace(" ", "")
    if normalized in {"image", "eeimage"}:
        return "Image"
    if normalized in {"imagecollection", "eeimagecollection"}:
        return "ImageCollection"
    if normalized in {
        "featurecollection",
        "table",
        "eefeaturecollection",
        "bigquerytable",
    }:
        return "FeatureCollection"
    return "Unknown"


def is_ee_initialized() -> bool:
    """Check if Earth Engine has been initialized."""
    global _ee_initialized
    return _ee_initialized


def mark_ee_initialized(value: bool = True) -> None:
    """Set the cached Earth Engine initialization flag."""
    global _ee_initialized, _last_init_error
    _ee_initialized = value
    if value:
        _last_init_error = None


def get_last_init_error() -> Optional[str]:
    """Return the most recent Earth Engine initialization error."""
    return _last_init_error


def _get_settings_project() -> Optional[str]:
    """Read the plugin's configured Earth Engine project ID."""
    try:
        from qgis.PyQt.QtCore import QSettings

        settings = QSettings()
        project = settings.value("GeeDataCatalogs/ee_project", "", type=str)
        project = project.strip() if project else ""
        return project or None
    except Exception:
        return None


def _check_credentials_exist() -> bool:
    """Check if Earth Engine credentials file exists.

    Returns:
        True if credentials file exists, False otherwise.
    """
    credentials_path = os.path.expanduser("~/.config/earthengine/credentials")
    return os.path.exists(credentials_path)


def initialize_ee(
    project: str = None,
    force: bool = False,
    credentials: Any = None,
) -> bool:
    """Initialize Earth Engine.

    Args:
        project: Google Cloud project ID. If None, reads from plugin settings
            then EE_PROJECT_ID.
        force: If True, reinitialize even when already initialized.
        credentials: Optional credentials object (e.g. a service-account
            ``google.oauth2.service_account.Credentials``). When provided,
            the on-disk OAuth credentials check is skipped.

    Returns:
        True if initialization was successful, False otherwise.
    """
    global _ee_initialized, _last_init_error

    if ee is None:
        _last_init_error = (
            "earthengine-api is not loaded. Please install earthengine-api, "
            "then restart QGIS if prompted."
        )
        return False

    _set_ee_user_agent_once()

    if _ee_initialized and not force:
        _last_init_error = None
        return True

    if force:
        _ee_initialized = False

    if project is None or project.strip() == "":
        project = _get_settings_project()
        if not project:
            project = os.environ.get("EE_PROJECT_ID", None)

    if credentials is None and not _check_credentials_exist():
        _last_init_error = (
            "Earth Engine credentials not found. Open Settings -> Earth Engine "
            "and click 'Authenticate (opens browser)', then retry initialization."
        )
        return False

    try:
        QgsMessageLog.logMessage(
            f"Attempting to initialize Earth Engine with project: {project if project else 'None'}",
            "GEE Data Catalogs",
            Qgis.MessageLevel.Info,
        )
        init_kwargs = {}
        if project:
            init_kwargs["project"] = project
        if credentials is not None:
            init_kwargs["credentials"] = credentials
        ee.Initialize(**init_kwargs)
        _ee_initialized = True
        _last_init_error = None
        _clear_tile_url_cache()
        return True
    except Exception as e:
        _ee_initialized = False
        project_desc = f"project={project!r}" if project else "no project"
        _last_init_error = (
            f"ee.Initialize({project_desc}) failed: {e!r}. "
            "Open Settings -> Earth Engine, click 'Initialize Earth Engine' "
            "to retest, then 'Authenticate (opens browser)' if needed."
        )
        return False


def try_auto_initialize_ee() -> bool:
    """Try to auto-initialize Earth Engine if EE_PROJECT_ID is set.

    Returns:
        True if initialization was successful, False otherwise.
    """
    global _ee_initialized, _last_init_error

    if _ee_initialized:
        return True

    if ee is None:
        return False

    _set_ee_user_agent_once()

    project = _get_settings_project()
    if not project:
        project = os.environ.get("EE_PROJECT_ID", None)
    if not project:
        return False

    try:
        ee.Initialize(project=project)
        _ee_initialized = True
        _last_init_error = None
        _clear_tile_url_cache()

        QgsMessageLog.logMessage(
            f"Earth Engine auto-initialized with project: {project}",
            "GEE Data Catalogs",
            Qgis.MessageLevel.Info,
        )
        return True
    except Exception as e:
        QgsMessageLog.logMessage(
            f"Failed to auto-initialize Earth Engine: {e}",
            "GEE Data Catalogs",
            Qgis.MessageLevel.Warning,
        )
        return False


def get_ee_tile_url(
    ee_object: Any,
    vis_params: Optional[Dict] = None,
    name: str = "",
) -> str:
    """Get an XYZ tile URL for an Earth Engine object.

    The synchronous ``getMapId()`` call to Earth Engine can take several
    seconds on first request. The result is cached in ``_tile_url_cache`` so
    repeated adds of the same (object, vis_params) pair return instantly.
    Wall-clock timing is logged on every cache miss so that "slow" can be
    distinguished from "hung" in the QGIS Log Messages panel.

    Args:
        ee_object: An Earth Engine Image, ImageCollection, or FeatureCollection.
        vis_params: Visualization parameters dictionary.
        name: Optional layer name, used only in log messages for clarity.

    Returns:
        XYZ tile URL string.
    """
    if ee is None:
        raise ImportError(
            "The 'ee' module is not installed. Please install earthengine-api."
        )

    vis_params = vis_params or {}

    # Handle ImageCollection by taking the first image or mosaic
    if isinstance(ee_object, ee.ImageCollection):
        ee_object = ee_object.mosaic()

    label = f" for '{name}'" if name else ""

    cache_key = _tile_cache_key(ee_object, vis_params)
    if cache_key is not None:
        cached = _tile_url_cache.get(cache_key)
        if cached is not None:
            QgsMessageLog.logMessage(
                f"Reusing cached tile URL{label}",
                "GEE Data Catalogs",
                Qgis.MessageLevel.Info,
            )
            return cached

    started = time.monotonic()
    try:
        map_id_dict = ee_object.getMapId(vis_params)
    except Exception as exc:
        elapsed = time.monotonic() - started
        QgsMessageLog.logMessage(
            f"Earth Engine getMapId failed after {elapsed:.2f}s{label}: {exc}",
            "GEE Data Catalogs",
            Qgis.MessageLevel.Warning,
        )
        raise

    elapsed = time.monotonic() - started
    QgsMessageLog.logMessage(
        f"Earth Engine getMapId completed in {elapsed:.2f}s{label}",
        "GEE Data Catalogs",
        Qgis.MessageLevel.Info,
    )

    tile_url = map_id_dict.get("tile_fetcher").url_format

    if cache_key is not None and tile_url:
        if len(_tile_url_cache) >= _TILE_CACHE_CAP:
            # FIFO eviction: drop the oldest entry (insertion order is
            # preserved by dict in Python 3.7+).
            oldest = next(iter(_tile_url_cache))
            del _tile_url_cache[oldest]
        _tile_url_cache[cache_key] = tile_url

    return tile_url


def _is_valid_qgis_layer(layer: Any) -> bool:
    """Return True when ``layer`` is a valid QGIS raster layer."""
    if not isinstance(layer, QgsRasterLayer):
        return False
    try:
        return bool(layer.isValid())
    except Exception:  # nosec B110
        return False


def _create_xyz_ee_layer(
    ee_object: Any,
    vis_params: Dict,
    name: str,
) -> QgsRasterLayer:
    """Create a QGIS XYZ raster layer for an Earth Engine object."""
    if isinstance(ee_object, (ee.Image, ee.ImageCollection)):
        tile_url = get_ee_tile_url(ee_object, vis_params, name=name)
        uri = _xyz_uri_from_tile_url(tile_url)
        return QgsRasterLayer(uri, name, "wms")

    if isinstance(ee_object, ee.FeatureCollection):
        valid_style_keys = {
            "color",
            "pointSize",
            "pointShape",
            "width",
            "fillColor",
            "styleProperty",
            "neighborhood",
            "lineType",
        }
        style_params = {k: v for k, v in vis_params.items() if k in valid_style_keys}
        styled_fc = ee_object
        if style_params:
            styled_fc = ee_object.style(**style_params)
        tile_url = get_ee_tile_url(styled_fc, {}, name=name)
        uri = _xyz_uri_from_tile_url(tile_url)
        return QgsRasterLayer(uri, name, "wms")

    raise TypeError(f"Unsupported Earth Engine object type: {type(ee_object)}")


def add_ee_layer(
    ee_object: Any,
    vis_params: Optional[Dict] = None,
    name: str = "EE Layer",
    shown: bool = True,
    opacity: float = 1.0,
) -> QgsRasterLayer:
    """Add an Earth Engine layer to the QGIS map.

    Args:
        ee_object: An Earth Engine Image, ImageCollection, or FeatureCollection.
        vis_params: Visualization parameters dictionary.
        name: Name for the layer.
        shown: Whether the layer should be visible.
        opacity: Layer opacity (0.0 to 1.0).

    Returns:
        QgsRasterLayer instance.
    """
    if ee is None:
        raise ImportError(
            "The 'ee' module is not installed. Please install earthengine-api."
        )

    vis_params = vis_params or {}

    # Remove existing layer with the same name if it exists
    project = QgsProject.instance()
    existing_layers = project.mapLayersByName(name)
    for existing_layer in existing_layers:
        project.removeMapLayer(existing_layer.id())

    # Remove from Inspector registry
    remove_ee_layer_from_registry(name)

    # Save current map extent to preserve it
    from qgis.utils import iface

    current_extent = None
    if iface and iface.mapCanvas():
        current_extent = iface.mapCanvas().extent()

    # Try to use qgis_geemap if available, but fall back to direct XYZ tiles
    # when it returns no layer or an invalid layer.
    layer = None
    try:
        from qgis_geemap.core.qgis_map import Map

        m = Map()
        layer = m.add_layer(ee_object, vis_params, name, shown, opacity)
        if not _is_valid_qgis_layer(layer):
            QgsMessageLog.logMessage(
                f"qgis_geemap did not create a valid layer for '{name}'. "
                "Falling back to direct Earth Engine XYZ tiles.",
                "GEE Data Catalogs",
                Qgis.MessageLevel.Warning,
            )
            layer = None
    except ImportError:
        layer = None
    except Exception as exc:
        QgsMessageLog.logMessage(
            f"qgis_geemap failed for '{name}': {exc}. Falling back to direct "
            "Earth Engine XYZ tiles.",
            "GEE Data Catalogs",
            Qgis.MessageLevel.Warning,
        )
        layer = None

    if layer is not None:
        # Restore the map extent after qgis_geemap adds the layer
        if current_extent and iface and iface.mapCanvas():
            iface.mapCanvas().setExtent(current_extent)
            iface.mapCanvas().refresh()

        # Register the layer for Inspector (important: register before returning)
        add_ee_layer_to_registry(name, ee_object, vis_params)

        # Persist EE metadata so the layer can be reconstructed on project reload.
        if isinstance(layer, QgsRasterLayer):
            _store_ee_layer_metadata(layer, ee_object, vis_params)

        return layer

    layer = _create_xyz_ee_layer(ee_object, vis_params, name)

    if not layer.isValid():
        raise ValueError(f"Failed to create valid layer: {name}")

    # Set opacity
    if hasattr(layer, "renderer") and layer.renderer():
        layer.renderer().setOpacity(opacity)

    # Add to project (False = don't add to legend first, we'll add manually)
    project = QgsProject.instance()
    project.addMapLayer(layer, False)

    # Add to legend at top
    root = project.layerTreeRoot()
    root.insertLayer(0, layer)

    # Set visibility
    layer_tree = project.layerTreeRoot().findLayer(layer.id())
    if layer_tree:
        layer_tree.setItemVisibilityChecked(shown)

    # Restore the map extent after adding the layer
    if current_extent and iface and iface.mapCanvas():
        iface.mapCanvas().setExtent(current_extent)
        iface.mapCanvas().refresh()

    # Register the layer for Inspector
    add_ee_layer_to_registry(name, ee_object, vis_params)

    # Store EE metadata in layer custom properties for project persistence
    _store_ee_layer_metadata(layer, ee_object, vis_params)

    return layer


def get_ee_layers() -> Dict:
    """Get the registry of Earth Engine layers.

    Returns:
        Dictionary mapping layer names to (ee_object, vis_params) tuples.
    """
    global _ee_layer_registry
    return _ee_layer_registry.copy()


def add_ee_layer_to_registry(
    name: str, ee_object: Any, vis_params: Optional[Dict] = None
):
    """Add an Earth Engine layer to the registry for Inspector.

    Args:
        name: Layer name.
        ee_object: Earth Engine object.
        vis_params: Visualization parameters.
    """
    global _ee_layer_registry
    _ee_layer_registry[name] = (ee_object, vis_params or {})


def remove_ee_layer_from_registry(name: str):
    """Remove an Earth Engine layer from the registry.

    Args:
        name: Layer name to remove.
    """
    global _ee_layer_registry
    _ee_layer_registry.pop(name, None)


def clear_ee_layer_registry():
    """Clear all layers from the registry."""
    global _ee_layer_registry
    _ee_layer_registry = {}


# Custom property keys for EE layer persistence
EE_ASSET_ID_KEY = "ee_asset_id"
EE_VIS_PARAMS_KEY = "ee_vis_params"
EE_OBJECT_TYPE_KEY = "ee_object_type"
EE_SERIALIZED_KEY = "ee_serialized"


def _store_ee_layer_metadata(
    layer: QgsRasterLayer, ee_object: Any, vis_params: Dict
) -> None:
    """Store Earth Engine metadata in layer custom properties.

    This enables layer refresh when reopening a QGIS project. In addition to
    the asset id (only present for pristine catalog assets), the full
    Earth Engine computation graph is serialized so that derived/computed
    objects produced from the Code tab can be reconstructed losslessly on
    project reload.

    Args:
        layer: The QGIS layer to store metadata on.
        ee_object: The Earth Engine object.
        vis_params: Visualization parameters dictionary.
    """
    if ee is None:
        return

    # Determine object type and asset ID
    asset_id = None
    object_type = None

    if isinstance(ee_object, ee.Image):
        object_type = "Image"
        try:
            # Try to get the asset ID from the image
            asset_id = ee_object.get("system:id").getInfo()
        except Exception:  # nosec B110
            pass
    elif isinstance(ee_object, ee.ImageCollection):
        object_type = "ImageCollection"
        try:
            asset_id = ee_object.get("system:id").getInfo()
        except Exception:  # nosec B110
            pass
    elif isinstance(ee_object, ee.FeatureCollection):
        object_type = "FeatureCollection"
        try:
            asset_id = ee_object.get("system:id").getInfo()
        except Exception:  # nosec B110
            pass

    # Store metadata as custom properties
    if asset_id:
        layer.setCustomProperty(EE_ASSET_ID_KEY, asset_id)
    if object_type:
        layer.setCustomProperty(EE_OBJECT_TYPE_KEY, object_type)
    if vis_params:
        layer.setCustomProperty(EE_VIS_PARAMS_KEY, json.dumps(vis_params))

    # Persist the full EE computation graph so derived/computed objects (e.g.
    # `image.normalizedDifference([...])` from the Code tab) can be restored
    # on project reload, not just pristine catalog assets.
    if object_type is not None:
        try:
            serialized = ee.serializer.toJSON(ee_object)
            layer.setCustomProperty(EE_SERIALIZED_KEY, serialized)
        except Exception as exc:
            QgsMessageLog.logMessage(
                f"Could not serialize EE object for layer '{layer.name()}': {exc}",
                "GEE Data Catalogs",
                Qgis.MessageLevel.Warning,
            )


def is_ee_layer(layer: QgsRasterLayer) -> bool:
    """Check if a layer is an Earth Engine layer.

    A layer is treated as an EE layer if it carries either an asset id or
    a serialized computation graph in its custom properties.

    Args:
        layer: The layer to check.

    Returns:
        True if the layer has EE metadata, False otherwise.
    """
    return (
        layer.customProperty(EE_ASSET_ID_KEY) is not None
        or layer.customProperty(EE_SERIALIZED_KEY) is not None
    )


def refresh_ee_layer(layer: QgsRasterLayer) -> bool:
    """Refresh an Earth Engine layer's tile URL.

    Regenerates the tile URL from stored metadata and updates the layer source.
    Reconstruction prefers the serialized computation graph (which round-trips
    derived/computed objects like ``image.normalizedDifference([...])``) and
    falls back to loading by asset id when only a pristine catalog asset was
    persisted.

    Args:
        layer: The QGIS layer to refresh.

    Returns:
        True if refresh was successful, False otherwise.
    """
    if ee is None:
        return False

    # Get stored metadata
    asset_id = layer.customProperty(EE_ASSET_ID_KEY)
    object_type = layer.customProperty(EE_OBJECT_TYPE_KEY)
    serialized = layer.customProperty(EE_SERIALIZED_KEY)
    vis_params_json = layer.customProperty(EE_VIS_PARAMS_KEY)

    if not asset_id and not serialized:
        return False

    # Parse visualization parameters
    vis_params = {}
    if vis_params_json:
        try:
            vis_params = json.loads(vis_params_json)
        except (json.JSONDecodeError, TypeError):
            pass

    try:
        # Reconstruct the EE object. Prefer the serialized computation graph so
        # derived objects survive a reload; fall back to asset-id loading.
        ee_object = None
        if serialized:
            try:
                ee_object = ee.deserializer.fromJSON(serialized)
            except Exception as exc:
                QgsMessageLog.logMessage(
                    f"Failed to deserialize EE graph for '{layer.name()}', "
                    f"falling back to asset id: {exc}",
                    "GEE Data Catalogs",
                    Qgis.MessageLevel.Info,
                )
        if ee_object is None and asset_id:
            ee_object = load_ee_asset(asset_id, object_type)
        if ee_object is None:
            return False

        # Register in the Inspector registry as soon as reconstruction succeeds.
        # Tile-URL regeneration below is best-effort and may fail on transient
        # EE/network issues; the registry must still reflect the live EE
        # object so Export/Inspector remain functional.
        add_ee_layer_to_registry(layer.name(), ee_object, vis_params)

        # Generate new tile URL
        if isinstance(ee_object, ee.FeatureCollection):
            # Handle FeatureCollection styling
            valid_style_keys = {
                "color",
                "pointSize",
                "pointShape",
                "width",
                "fillColor",
                "styleProperty",
                "neighborhood",
                "lineType",
            }
            style_params = {
                k: v for k, v in vis_params.items() if k in valid_style_keys
            }
            styled_fc = ee_object
            if style_params:
                styled_fc = ee_object.style(**style_params)
            tile_url = get_ee_tile_url(styled_fc, {}, name=layer.name())
        else:
            tile_url = get_ee_tile_url(ee_object, vis_params, name=layer.name())

        # Update layer source
        new_uri = _xyz_uri_from_tile_url(tile_url)
        layer.setDataSource(new_uri, layer.name(), "wms")

        QgsMessageLog.logMessage(
            f"Refreshed EE layer: {layer.name()}",
            "GEE Data Catalogs",
            Qgis.MessageLevel.Info,
        )
        return True

    except Exception as e:
        QgsMessageLog.logMessage(
            f"Failed to refresh EE layer '{layer.name()}': {e}",
            "GEE Data Catalogs",
            Qgis.MessageLevel.Warning,
        )
        return False


def refresh_all_ee_layers() -> int:
    """Refresh all Earth Engine layers in the current project.

    Returns:
        Number of layers successfully refreshed.
    """
    if ee is None:
        return 0

    project = QgsProject.instance()
    refreshed_count = 0

    for layer in project.mapLayers().values():
        if isinstance(layer, QgsRasterLayer) and is_ee_layer(layer):
            if refresh_ee_layer(layer):
                refreshed_count += 1

    return refreshed_count


def rebuild_ee_layer_registry() -> int:
    """Rebuild the in-memory EE layer registry from QGIS layer custom properties.

    This is a lightweight counterpart to :func:`refresh_all_ee_layers`: it
    reconstructs ``ee.Image`` / ``ee.ImageCollection`` / ``ee.FeatureCollection``
    objects from the metadata stored on each ``QgsRasterLayer`` (via
    ``ee.deserializer.fromJSON`` or the asset-id constructor) and registers them
    so the Export/Inspector tabs can find them. It does **not** regenerate tile
    URLs or call ``getMapId``, so it is safe to invoke from UI handlers like
    tab-change or refresh-button click without triggering network requests.

    Returns:
        Number of layers added to the registry.
    """
    if ee is None:
        return 0

    project = QgsProject.instance()
    rebuilt_count = 0

    for layer in project.mapLayers().values():
        if not (isinstance(layer, QgsRasterLayer) and is_ee_layer(layer)):
            continue

        asset_id = layer.customProperty(EE_ASSET_ID_KEY)
        object_type = layer.customProperty(EE_OBJECT_TYPE_KEY)
        serialized = layer.customProperty(EE_SERIALIZED_KEY)
        vis_params_json = layer.customProperty(EE_VIS_PARAMS_KEY)

        vis_params: Dict = {}
        if vis_params_json:
            try:
                vis_params = json.loads(vis_params_json)
            except (json.JSONDecodeError, TypeError):
                pass

        ee_object = None
        if serialized:
            try:
                ee_object = ee.deserializer.fromJSON(serialized)
            except Exception as exc:
                QgsMessageLog.logMessage(
                    f"Failed to deserialize EE graph for '{layer.name()}', "
                    f"falling back to asset id: {exc}",
                    "GEE Data Catalogs",
                    Qgis.MessageLevel.Info,
                )
        if ee_object is None and asset_id:
            try:
                ee_object = load_ee_asset(asset_id, object_type)
            except Exception as exc:
                QgsMessageLog.logMessage(
                    f"Could not reconstruct EE object for '{layer.name()}': {exc}",
                    "GEE Data Catalogs",
                    Qgis.MessageLevel.Warning,
                )
                continue
        if ee_object is None:
            continue

        add_ee_layer_to_registry(layer.name(), ee_object, vis_params)
        rebuilt_count += 1

    return rebuilt_count


def detect_asset_type(asset_id: str) -> str:
    """Detect the type of an Earth Engine asset.

    Args:
        asset_id: The asset ID to check.

    Returns:
        One of: "Image", "ImageCollection", "FeatureCollection", "Table", or "Unknown"
    """
    if ee is None:
        raise ImportError("Earth Engine API not available")

    # Prefer asset metadata. It is much cheaper than evaluating Image/
    # ImageCollection objects with getInfo(), and avoids long UI stalls.
    try:
        asset_info = ee.data.getAsset(asset_id)
        metadata_type = _normalize_ee_asset_type(asset_info.get("type"))
        if metadata_type != "Unknown":
            return metadata_type
    except Exception as metadata_err:
        QgsMessageLog.logMessage(
            f"Asset metadata lookup failed for {asset_id}: {metadata_err}",
            "GEE Data Catalogs",
            Qgis.MessageLevel.Info,
        )

    # Try Image first
    try:
        image = ee.Image(asset_id)
        # Try to get a property to verify it's actually an Image
        image.bandNames().getInfo()
        return "Image"
    except Exception as img_err:
        # Check if error indicates it's not an Image
        img_error_str = str(img_err).lower()
        if "imagecollection" in img_error_str:
            return "ImageCollection"
        if "featurecollection" in img_error_str or "table" in img_error_str:
            return "FeatureCollection"

    # Try ImageCollection
    try:
        collection = ee.ImageCollection(asset_id)
        # Try to get size to verify
        collection.size().getInfo()
        return "ImageCollection"
    except Exception as ic_err:
        ic_error_str = str(ic_err).lower()
        if "image" in ic_error_str and "imagecollection" not in ic_error_str:
            return "Image"
        if "featurecollection" in ic_error_str or "table" in ic_error_str:
            return "FeatureCollection"

    # Try FeatureCollection
    try:
        fc = ee.FeatureCollection(asset_id)
        fc.size().getInfo()
        return "FeatureCollection"
    except Exception:  # nosec B110
        pass

    return "Unknown"


def load_ee_asset(asset_id: str, asset_type: str = None) -> Any:
    """Load an Earth Engine asset with the correct type.

    Args:
        asset_id: The asset ID to load.
        asset_type: Optional type hint ("Image", "ImageCollection", "FeatureCollection").
                    If not provided, type will be auto-detected.

    Returns:
        The loaded Earth Engine object (ee.Image, ee.ImageCollection, or ee.FeatureCollection).
    """
    if ee is None:
        raise ImportError("Earth Engine API not available")

    if asset_type is None:
        asset_type = detect_asset_type(asset_id)

    if asset_type == "Image":
        return ee.Image(asset_id)
    elif asset_type == "ImageCollection":
        return ee.ImageCollection(asset_id)
    elif asset_type == "FeatureCollection":
        return ee.FeatureCollection(asset_id)
    else:
        # Default to trying Image, then ImageCollection, then FeatureCollection
        for loader, name in [
            (ee.Image, "Image"),
            (ee.ImageCollection, "ImageCollection"),
            (ee.FeatureCollection, "FeatureCollection"),
        ]:
            try:
                obj = loader(asset_id)
                # Verify it works
                if name == "Image":
                    obj.bandNames().getInfo()
                else:
                    obj.size().getInfo()
                return obj
            except Exception:  # nosec B112
                continue
        raise ValueError(f"Could not load asset: {asset_id}")


def filter_image_collection(
    collection: Any,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    bbox: Optional[List[float]] = None,
    cloud_cover: Optional[float] = None,
    cloud_property: str = "CLOUDY_PIXEL_PERCENTAGE",
) -> Any:
    """Filter an ImageCollection by date, bounds, and cloud cover.

    Args:
        collection: An Earth Engine ImageCollection.
        start_date: Start date string (YYYY-MM-DD).
        end_date: End date string (YYYY-MM-DD).
        bbox: Bounding box as [west, south, east, north].
        cloud_cover: Maximum cloud cover percentage (0-100).
        cloud_property: Name of the cloud cover property.

    Returns:
        Filtered ImageCollection.
    """
    if ee is None:
        raise ImportError("Earth Engine API not available")

    filtered = collection

    # Filter by date
    if start_date and end_date:
        filtered = filtered.filterDate(start_date, end_date)
    elif start_date:
        filtered = filtered.filterDate(start_date, "2099-12-31")
    elif end_date:
        filtered = filtered.filterDate("1970-01-01", end_date)

    # Filter by bounds
    if bbox and len(bbox) == 4:
        geometry = ee.Geometry.Rectangle(bbox)
        filtered = filtered.filterBounds(geometry)

    # Filter by cloud cover
    if cloud_cover is not None:
        filtered = filtered.filter(ee.Filter.lt(cloud_property, cloud_cover))

    return filtered
