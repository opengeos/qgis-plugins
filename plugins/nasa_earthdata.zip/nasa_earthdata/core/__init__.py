"""
NASA Earthdata Plugin Core Module

This module contains the core dependency management components including
standalone Python downloading and virtual environment management.
"""
